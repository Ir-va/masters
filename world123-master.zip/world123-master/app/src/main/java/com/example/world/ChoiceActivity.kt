package com.example.world

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class ChoiceActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_choice)
    }

    fun log(view: View) {
        val int=Intent(this,SigninActivity::class.java)
        startActivity(int)
    }

    fun reg(view: View) {
        val inte=Intent(this,SignupActivity::class.java)
        startActivity(inte)
    }
}